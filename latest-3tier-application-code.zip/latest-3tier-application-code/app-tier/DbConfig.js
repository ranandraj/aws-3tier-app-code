module.exports = Object.freeze({
    DB_HOST : 'rdsdbendpoint',
    DB_USER : 'admin',
    DB_PWD : 'admin2023',
    DB_DATABASE : 'webappdb'
});